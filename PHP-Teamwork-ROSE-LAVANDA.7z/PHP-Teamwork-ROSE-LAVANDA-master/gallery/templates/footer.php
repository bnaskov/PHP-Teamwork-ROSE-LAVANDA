        <div id="fb-root"></div>
        <script>(function(d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) return;
                js = d.createElement(s); js.id = id;
                js.src = "//connect.facebook.net/bg_BG/sdk.js#xfbml=1&version=v2.0";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>
        <footer>
            <div class="logo">
                <a href="http://softuni.bg"><img src="images/softLogo.png" alt=""></a>
            </div>
            <div>
                <div class="center">
                    <h4>Our Inspiration</h4>
                </div>
                <div class="center">
                    <ul>
                        <li><a href="http://picasa.google.com/" target="_blank" ><img src="images/picasa-logo.png" alt=""></a></li>
                        <li><a href="https://www.flickr.com/" target="_blank"><img src="images/Flickr_logo.png" alt=""></a></li>
                        <li><a href="http://instagram.com/" target="_blank"><img src="images/Instagram-logo.png" alt=""></a></li>
                        <li><a href="http://www.500px.com/" target="_blank"><img src="images/500px.png" alt=""></a></li>
                    </ul>

                </div>
            </div>
            <div>
                <a href="https://www.facebook.com/pages/%D0%93%D0%B0%D0%BB%D0%B5%D1%80%D0%B8%D1%8F-Rose-Lavanda/1460284694256938?sk=timeline" target="_blank">
                    <img src="images/logo.png" />
                </a>
            </div>
        </footer>
    </body>
</html>